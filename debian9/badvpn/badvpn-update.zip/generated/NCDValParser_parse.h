#define COMMA                           1
#define CURLY_OPEN                      2
#define CURLY_CLOSE                     3
#define COLON                           4
#define BRACKET_OPEN                    5
#define BRACKET_CLOSE                   6
#define STRING                          7
